import customtkinter as ctk
from tkinter import messagebox
from admin import create_event, get_all_events, get_all_registrations, delete_event

def open_admin_dashboard():
    app = ctk.CTk()
    app.title("Admin Dashboard")
    app.geometry("700x500")

def refresh_events():
    events = get_all_events()
    if events:
        event_options = [f"{e['event_id']} - {e['event_name']}" for e in events]
        event_box.configure(values=event_options)  # ✅ This updates the dropdown
        if event_options:
            event_box.set(event_options[0])  # Set the first item as selected
    else:
        event_box.configure(values=["No events available"])
        event_box.set("No events available")
        for e in get_all_events():
            event_box.insert(ctk.END, f"{e['event_id']}: {e['event_name']}")

    def refresh_registrations():
        reg_box.delete(0, ctk.END)
        for r in get_all_registrations():
            reg_box.insert(ctk.END, f"{r['student_name']} -> {r['event_name']} on {r['registration_date']}")

    def handle_create():
        name = name_entry.get()
        date = date_entry.get()
        venue = venue_entry.get()
        if name and date and venue:
            create_event(name, date, venue)
            refresh_events()
            messagebox.showinfo("✅", "Event created successfully!")

    def handle_delete():
        selection = event_box.get()
        if ":" in selection:
            event_id = int(selection.split(":")[0])
            delete_event(event_id)
            refresh_events()
            messagebox.showinfo("✅", "Event deleted.")

    ctk.CTkLabel(app, text="Create Event", font=ctk.CTkFont(size=16)).pack(pady=5)
    name_entry = ctk.CTkEntry(app, placeholder_text="Event Name")
    name_entry.pack(pady=2)
    date_entry = ctk.CTkEntry(app, placeholder_text="YYYY-MM-DD")
    date_entry.pack(pady=2)
    venue_entry = ctk.CTkEntry(app, placeholder_text="Venue")
    venue_entry.pack(pady=2)
    ctk.CTkButton(app, text="Create", command=handle_create).pack(pady=5)

    ctk.CTkLabel(app, text="All Events").pack()
    event_box = ctk.CTkComboBox(app, values=[], width=300)
    event_box.pack(pady=5)

    ctk.CTkButton(app, text="Delete Selected Event", command=handle_delete).pack(pady=10)

    ctk.CTkLabel(app, text="All Registrations").pack()
    reg_box = ctk.CTkTextbox(app, height=150, width=500)
    reg_box.pack(pady=5)

    refresh_events()
    refresh_registrations()

    app.mainloop()
