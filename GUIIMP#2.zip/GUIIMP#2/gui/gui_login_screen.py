import customtkinter as ctk
from gui.gui_student_dashboard import open_student_dashboard
from gui.gui_admin_dashboard import open_admin_dashboard
from student import validate_student_login
from admin import validate_admin_login

class LoginApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Event Registration System")
        self.geometry("400x300")
        self.resizable(False, False)

        self.label = ctk.CTkLabel(self, text="Login as:", font=ctk.CTkFont(size=18))
        self.label.pack(pady=20)

        self.admin_btn = ctk.CTkButton(self, text="Admin", command=self.admin_login)
        self.admin_btn.pack(pady=10)

        self.student_btn = ctk.CTkButton(self, text="Student", command=self.student_login)
        self.student_btn.pack(pady=10)

    def admin_login(self):
        if validate_admin_login():
            self.destroy()
            open_admin_dashboard()

    def student_login(self):
        student_id = validate_student_login()
        if student_id:
            self.destroy()
            open_student_dashboard(student_id)
