import customtkinter as ctk
from student import get_all_events, register_student_for_event
from tkinter import messagebox

def open_student_dashboard(student_id):
    app = ctk.CTk()
    app.title("Student Dashboard")
    app.geometry("500x400")

    def refresh_events():
        event_listbox.delete(0, ctk.END)
        for event in get_all_events():
            event_listbox.insert(ctk.END, f"{event['event_id']}: {event['event_name']} on {event['event_date']}")

    def handle_register():
        selection = event_listbox.get()
        if ":" in selection:
            event_id = int(selection.split(":")[0])
            message = register_student_for_event(student_id, event_id)
            messagebox.showinfo("Status", message)

    ctk.CTkLabel(app, text="Available Events", font=ctk.CTkFont(size=16)).pack(pady=10)

    event_listbox = ctk.CTkComboBox(app, values=[], width=400)
    event_listbox.pack(pady=10)

    ctk.CTkButton(app, text="Register", command=handle_register).pack(pady=10)

    refresh_events()
    app.mainloop()
