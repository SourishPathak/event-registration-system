import customtkinter as ctk
from gui.login import LoginFrame

class EventRegistrationApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Event Registration System")
        self.geometry("600x400")
        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("dark-blue")

        self.login_frame = LoginFrame(self)
        self.login_frame.pack(fill="both", expand=True)
