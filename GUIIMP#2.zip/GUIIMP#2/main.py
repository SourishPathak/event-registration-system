from gui.gui_login_screen import LoginApp

if __name__ == "__main__":
    app = LoginApp()
    app.mainloop()
