from datetime import datetime
import customtkinter as ctk
from tkinter import simpledialog, messagebox
from db import get_connection

def validate_student_login():
    root = ctk.CTk()
    root.withdraw()

    try:
        student_id = simpledialog.askinteger("Student Login", "Enter your Student ID:")
        if not student_id:
            return None

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM students WHERE student_id = %s", (student_id,))
        student = cursor.fetchone()
        conn.close()

        if student:
            return student_id
        else:
            messagebox.showerror("Login Failed", "❌ Student not found.")
            return None
    except Exception as e:
        print("Login error:", e)
        return None

def get_all_events():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM events")
    events = cursor.fetchall()
    conn.close()
    return events

def register_student_for_event(student_id, event_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM registrations WHERE student_id = %s AND event_id = %s", (student_id, event_id))
    if cursor.fetchone():
        return "⚠️ Already registered."
    cursor.execute("INSERT INTO registrations (student_id, event_id, registration_date) VALUES (%s, %s, %s)",
                   (student_id, event_id, datetime.today().strftime('%Y-%m-%d')))
    conn.commit()
    conn.close()
    return "✅ Registration Successful"
